﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeYourMarket.Service
{
    public enum CacheKeys
    {
        Settings,
        SettingDictionary,
        Categories,
        ListingTypes,
        ContentPages,
        EmailTemplates,
        Statistics,
        LocationsRef,
        AspNetUserCategories
    }
}
